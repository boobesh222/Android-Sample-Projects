package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.concurrent.ExecutionException;

/**
 * Created by boobeshb on 29-03-2016.
 */
public class FinalproductsviewFragments extends Fragment {

    Bundle bundle;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        bundle=getArguments();

        String df=bundle.getString("hai");
        int position=bundle.getInt("position");
        Retailappmodel.image.clear();
        Retailappmodel.price.clear();
        Retailappmodel.productsize.clear();
        System.out.println("POSITION VALUE IN BUNDLE " + position +"images link size" +Retailappmodel.image.size());
       /* System.out.println("sf " + df);*/
            JSONArray sdf = Retailappmodel.subcategoriesarray.get(position);
            for (int z = 0; z < sdf.length(); z++) {
                try {
                    Retailappmodel.image.add(sdf.getJSONObject(z).getString("list"));
                    Retailappmodel.price.add(sdf.getJSONObject(z).getString("price"));
                    Retailappmodel.productsize.add(sdf.getJSONObject(z).getString("sizes"));
                    System.out.println(sdf.getJSONObject(z).getString("list") + "   " + "SUBCATEGORIES JSON OBJECTS" + z);
                    System.out.println(sdf.getJSONObject(z).getString("price") + "price");
                    System.out.println(sdf.getJSONObject(z).get("sizes") + "size");
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        System.out.println("images link size after for loop" + Retailappmodel.image.size());

        /*new Fetchimage(getActivity()).fetchimageonly();*/

        try {

            new Productimageparse(getActivity()).execute().get();
            System.out.println("AFTER PRODUCT PARSE");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        System.out.println("ON CREATE VIEW " +Retailappmodel.bitmapimages.size() );
        View view=inflater.inflate(R.layout.finalproducts,null);
        GridView gridView=(GridView)view.findViewById(R.id.finalproducts_gridview);
        System.out.println("ONCREATE VIEW BEFORE RETURN");
        System.out.println("retail app products image size" +Retailappmodel.productimages.size());
        gridView.setAdapter(new Finalproductsgridviewadapter(getActivity()));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getActivity(), "position" + position, Toast.LENGTH_SHORT).show();
                Bundle bundle=new Bundle();
                bundle.putInt("position", position);
                Fragment fragment=new Landingpagefragments();
                fragment.setArguments(bundle);
                int a=getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment).addToBackStack(null).commit();
                System.out.println("back stack return value " + a);

            }
        });
        return view;
    }
}



/*
for(int w=0;w< Retailappmodel.subcategoriesarray.size();w++){
        System.out.println("FOR LOOP JSON ARRAY"+ Retailappmodel.subcategoriesarray.get(w));
        JSONArray sdf= Retailappmodel.subcategoriesarray.get(w);
        for(int z=0;z<sdf.length();z++){
        System.out.println(sdf.getJSONObject(z).getString("list") + "   " +  "SUBCATEGORIES JSON OBJECTS" + z);
        System.out.println(sdf.getJSONObject(z).getString("price")+"price");
        System.out.println(sdf.getJSONObject(z).get("sizes")+"size");

        }
        }
*/
