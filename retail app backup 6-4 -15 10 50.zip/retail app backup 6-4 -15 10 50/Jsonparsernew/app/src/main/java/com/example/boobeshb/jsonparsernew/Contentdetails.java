package com.example.boobeshb.jsonparsernew;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by boobeshb on 28-03-2016.
 */
public class Contentdetails  {

    Context context;
    String selectedoption;
    int position;
    public static  JSONArray jo;
    public Contentdetails( String selectedoption,Context context,int position) {
        this.context = context;
        this.selectedoption = selectedoption;
        this.position=position;
        getProductcontents();
    }



    public void getProductcontents(){

        try {
            System.out.println("TRY BLOCK"+Retailappmodel.jsonObjectList.get(position).getString("1"));
            JSONObject array=Retailappmodel.jsonObjectList.get(position);
            System.out.println("TRY 2"+Retailappmodel.jsonObjectList.get(position));
            JSONArray nameslist=array.names();
            JSONArray names=array.getJSONArray("1");


            int arraylength=names.length();
            Retailappmodel.subcategoriesarray.clear();
            Retailappmodel.varientsname.clear();
            for(int j=0;j<names.length();j++){
                System.out.println("JSON ARRAY" + names.getJSONObject(j));
                JSONObject obj=names.getJSONObject(j);
                System.out.println(obj.getString("varient") + "FINAL ITEMS LIST");
                System.out.println(obj.getString("subcategories") + "SUB CATEGORIES");
                jo=obj.getJSONArray("subcategories");

                System.out.println("subcat jo length" + j + jo.length());
                Retailappmodel.subcategoriesarray.add(jo);
                /*System.out.println(" list of web links for images" + jo.getString("list"));*//*
                */
                Retailappmodel.varientsname.add(obj.getString("varient"));

            }

            /*for(int w=0;w< Retailappmodel.subcategoriesarray.size();w++){
                System.out.println("FOR LOOP JSON ARRAY"+ Retailappmodel.subcategoriesarray.get(w));
                JSONArray sdf= Retailappmodel.subcategoriesarray.get(w);
                for(int z=0;z<sdf.length();z++){
                    System.out.println(sdf.getJSONObject(z).getString("list") + "   " +  "SUBCATEGORIES JSON OBJECTS" + z);
                    System.out.println(sdf.getJSONObject(z).getString("price")+"price");
                    System.out.println(sdf.getJSONObject(z).get("sizes")+"size");

                }
            }*/

            // System.out.println(array.getString("varient")+"VARIENTS FOR OPTIONS");
            for (int i=0;i<array.length();i++){
                System.out.println("FOR LOOP" +array.names());
            }

            for(String s:Retailappmodel.varientsname){
                System.out.println(s+"inner cat");

            }

        }catch (JSONException e){
            e.printStackTrace();
        }
    }

}
