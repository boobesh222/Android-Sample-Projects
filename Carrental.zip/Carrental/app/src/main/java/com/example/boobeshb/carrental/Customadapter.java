package com.example.boobeshb.carrental;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by boobeshb on 26-02-2016.
 */
public class Customadapter extends BaseAdapter {
    int imagesc[];
    int pickup[];
    int cmplogos[];
    int carslogos[];
    Context c;
    LayoutInflater inf;

    public Customadapter(Context context,int img[] , int [] pick,int [] cars, int [] cmp ) {
       imagesc=img;
        pickup=pick;
        cmplogos=cmp;
        carslogos=cars;
        c=context;
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        inf=(LayoutInflater)c.getSystemService(c.LAYOUT_INFLATER_SERVICE);
        View listlayout=(View)inf.inflate(R.layout.listviewlayout,null);
        TextView listview_modelname=(TextView)listlayout.findViewById(R.id.listview_modelname);
        ImageView person=(ImageView)listlayout.findViewById(R.id.image1);
        ImageView xcross=(ImageView)listlayout.findViewById(R.id.image2);
        ImageView chiller=(ImageView)listlayout.findViewById(R.id.image3);
        ImageView gpattern=(ImageView)listlayout.findViewById(R.id.image4);
        ImageView heater=(ImageView)listlayout.findViewById(R.id.image5);
        ImageView  ac=(ImageView)listlayout.findViewById(R.id.image6);
        ImageView location=(ImageView)listlayout.findViewById(R.id.meetandgreet);
        ImageView carimage=(ImageView)listlayout.findViewById(R.id.carimage);
        TextView similar=(TextView)listlayout.findViewById(R.id.similar);
        ImageView separationline=(ImageView)listlayout.findViewById(R.id.separationline);
        ImageView companylogo=(ImageView)listlayout.findViewById(R.id.companylogo);
        TextView reviews=(TextView)listlayout.findViewById(R.id.reviews);
        TextView price=(TextView)listlayout.findViewById(R.id.price);
        TextView hirerate=(TextView)listlayout.findViewById(R.id.hirerate);
        listview_modelname.setText("Compact 4-5 Doors");
        person.setImageResource(imagesc[0]);
        xcross.setImageResource(imagesc[2]);
        chiller.setImageResource(imagesc[1]);
        gpattern.setImageResource(imagesc[3]);
        heater.setImageResource(imagesc[4]);
        ac.setImageResource(imagesc[5]);
        if(position%2==0){
            location.setImageResource(pickup[0]);
        }else {
            location.setImageResource(pickup[1]);
        }
        carimage.setImageResource(carslogos[position]);
        similar.setText("0r Similar");
        separationline.setImageResource(R.drawable.lineg);
        companylogo.setImageResource(cmplogos[position]);
        reviews.setText("504 reviews");
        price.setText("$ 100");
        hirerate.setText("$ 22 / hour ");
        return listlayout;
    }
}
