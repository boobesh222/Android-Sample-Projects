package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

/**
 * Created by boobeshb on 28-03-2016.
 */
public class Genericlistview extends BaseAdapter {

    Context c;
    public Genericlistview(Context c) {
        this.c=c;
    }


    @Override
    public int getCount() {
        return Retailappmodel.categorynames.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        System.out.println("GET VIEW GENERIC LISDT VIEW " + position);
         LayoutInflater layoutInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View v = layoutInflater.inflate(R.layout.viewlayout, null);
            ImageView iv = (ImageView) v.findViewById(R.id.imageview);
            TextView textView = (TextView) v.findViewById(R.id.textview);
            new Imageparse(c,position,iv,textView).execute();
            /*iv.setImageBitmap(Retailappmodel.bitmapimages.get(0));
            textView.setText(Retailappmodel.categorynames.get(position));
            */
        return v;


    }
}
