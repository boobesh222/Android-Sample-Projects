package com.example.boobeshb.jsonparsernew;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import org.json.JSONObject;

/**
 * Created by boobeshb on 24-03-2016.
 */
public class JSONparse extends AsyncTask<String, String, JSONObject> {

    String Url = "http://www.json-generator.com/api/json/get/bSrsNpHOgi?indent=2";

    ProgressDialog prgdialog;

    Context context;
    public JSONparse(Context c) {
     context=c;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();


           /* Fragment sjhd=new listviewFrag();*/


    }


    @Override
    protected JSONObject doInBackground(String... params) {
        Jsonparser parser = new Jsonparser();
        JSONObject object = parser.getJSONfromURL(Url);
        return object;
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(JSONObject jsonObject) {
        super.onPostExecute(jsonObject);
        System.out.println("ON POST EXECUTE json parse");
        Intent i=new Intent(context,slideractivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

}
