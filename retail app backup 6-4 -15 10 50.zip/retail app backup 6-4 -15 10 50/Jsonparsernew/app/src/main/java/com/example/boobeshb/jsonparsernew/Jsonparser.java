package com.example.boobeshb.jsonparsernew;

import android.os.Bundle;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 * Created by boobeshb on 01-03-2016.
 */
public class Jsonparser {

    InputStream inputStream=null;
    JSONObject jsonObject;
    String json;

    public JSONObject getJSONfromURL(String URL){

       try{
           DefaultHttpClient httpclient = new DefaultHttpClient();
           HttpPost hpost = new HttpPost(URL);
           HttpResponse response = httpclient.execute(hpost);
           HttpEntity entity=response.getEntity();
            inputStream =entity.getContent();
       }catch (UnsupportedEncodingException e){
           e.printStackTrace();
       }catch (ClientProtocolException e) {
           e.printStackTrace();
       } catch (IOException e) {
           e.printStackTrace();
       }

        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(inputStream,"ISO-8859-1"),8);
            StringBuilder sb=new StringBuilder();
            String newline=null;
            while ((newline=br.readLine())!=null){
               // newline=br.readLine();
                sb.append(newline+"\n");

            }
            inputStream.close();
            json=sb.toString();
            System.out.println(json +"BUILT JSON STRING ");
        }catch (Exception e){
            e.printStackTrace();
        }

        try{
            jsonObject=new JSONObject(json);
            System.out.println(json + "BUILT JSON STRING ");
            Retailappmodel.jsonObject=jsonObject;
        }catch (JSONException e){
            e.printStackTrace();
        }

        return  jsonObject;
    }
}
