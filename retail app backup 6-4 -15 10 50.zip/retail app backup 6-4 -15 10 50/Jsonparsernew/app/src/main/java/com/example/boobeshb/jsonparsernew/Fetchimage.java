package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * Created by boobeshb on 28-03-2016.
 */
public class Fetchimage  {

    JSONArray user;
    String name;

    List<String> image= new ArrayList<String>();
    List<String> categoryname=new ArrayList<String>();
    JSONObject values;

    List<JSONObject> jsonObjectslist;
    Context context;
    String menus ;

    public Fetchimage(Context context,String menus) {
        this.context = context;
        this.menus=menus;
    }



    public void fetchimage() {
        try {

            System.out.println(Retailappmodel.jsonObject.length() + "LENGTH OF JSON OBJECT ");
            user = Retailappmodel.jsonObject.getJSONArray(menus);
            int nodelength = user.length();
            System.out.println(nodelength + "nodelength");
            Retailappmodel.image.clear();
            Retailappmodel.categorynames.clear();
            Retailappmodel.jsonObjectList .clear();
            for (int i = 0; i < nodelength; i++) {

                values = user.getJSONObject(i);
                JSONArray listNames = values.names();
                   /* JSONArray valuesone=values.getJSONArray("1");
                    System.out.println(listNames.length()+"LIST NAMES LENGTH" +listNames.toString());
                    System.out.println(i + "i value");*/
                String category1 = values.getString("category");
                Retailappmodel.categorynames.add(category1);
                String images = values.getString("images");
                Retailappmodel.image.add(images);
                Toast.makeText(context, "image size " + image.size(), Toast.LENGTH_SHORT).show();
                Retailappmodel.jsonObjectList.add(values);

            }

           /* new Imageparse(context).execute().get();*/
            for (String s : Retailappmodel.image) {
                System.out.println(s + "IMAGES WEBSITES");
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }/*catch (InterruptedException e){
             e.printStackTrace();
        }catch (ExecutionException e ){
        }*/

    }





   /* public  void fetchimageonly(){

        try {
            new Productimageparse(context).execute().get();

        }catch (InterruptedException e){
            e.printStackTrace();
        }catch (ExecutionException e){
            e.printStackTrace();
        }
        }*/
}
