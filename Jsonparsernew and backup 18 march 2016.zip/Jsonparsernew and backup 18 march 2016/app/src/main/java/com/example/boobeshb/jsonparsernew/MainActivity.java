package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {


    Button men;
    Button women;
    Button kids;


    /*String Url="http://www.json-generator.com/api/json/get/bPLTlSDFOW?indent=2";
    */

    String Url="http://www.json-generator.com/api/json/get/bSrsNpHOgi?indent=2";
    ListView lv;
    List<String> category;
    List<String> clothing;
    List<JSONObject> jsonObjectslist;
    List<String> image= new ArrayList<String>();
    List<Bitmap> imagesarraybitmap;

    Nextpage nextpageclass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        men = (Button) findViewById(R.id.men);
        women = (Button) findViewById(R.id.women);
        kids = (Button) findViewById(R.id.kids);
        final String id = men.getText().toString();
        final String two = women.getText().toString();
        final String three = kids.getText().toString();


        men.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new JSONparse(id).execute();
                new MainActivity.Imageparse().execute();
                /*System.out.println(count() + "COUNT VALUE");*/
            }

        });


        women.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("women clicked");
                new JSONparse(two).execute();
                new MainActivity.Imageparse().execute();
            }
        });

        kids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("kid clicked");
                new JSONparse(three).execute();
                new MainActivity.Imageparse().execute();
            }
        });

        /*System.out.println(count() + "COUNT VALUE");*/

    }

    /*public void invoke(){
        System.out.println("INVOKE METHOD");
        new Imageparse().execute();
    }*/

    public class JSONparse extends AsyncTask<String, String, JSONObject> {
        String buttonText;
        String node;

        public JSONparse(String id) {
            buttonText = id;
        }

        ProgressDialog prgdialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            lv = (ListView) findViewById(R.id.listview);
            prgdialog = new ProgressDialog(MainActivity.this, ProgressDialog.STYLE_SPINNER);
            prgdialog.setMessage("Getting data.....");
            prgdialog.setIndeterminate(false);
            prgdialog.setCancelable(true);
            prgdialog.show();
        }


        @Override
        protected JSONObject doInBackground(String... params) {
            Jsonparser parser = new Jsonparser();
            JSONObject object = parser.getJSONfromURL(Url);
            return object;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);

            prgdialog.dismiss();
            JSONArray user;
            JSONObject values;
            category = new ArrayList<String>();
            clothing = new ArrayList<String>();

            jsonObjectslist = new ArrayList<JSONObject>();
            if (buttonText == "men" || buttonText.equals("men")) {
                node = "men";
                System.out.println(node + "NODE VALUE");
            } else if (buttonText == "women" || buttonText.equals("women")) {
                node = "women";
                System.out.println(node + "NODE VALUE");
            } else if (buttonText == "kids" || buttonText.equals("kids")) {
                node = "kids";
                System.out.println(node + "NODE VALUE");
            }


            try {
                user = jsonObject.getJSONArray(node);
                int nodelength = user.length();
                System.out.println(nodelength + "nodelength");
                image.clear();
                for (int i = 0; i < nodelength; i++) {

                    values = user.getJSONObject(i);
                    JSONArray listNames = values.names();
                   /* JSONArray valuesone=values.getJSONArray("1");
                    System.out.println(listNames.length()+"LIST NAMES LENGTH" +listNames.toString());
                    System.out.println(i + "i value");*/
                    String category1 = values.getString("category");
                    String images = values.getString("images");
                    category.add(category1);

                    image.add(images);
                    jsonObjectslist.add(values);
                   /* for (int j=0;j<valuesone.length();j++){
                        JSONObject jobj=valuesone.getJSONObject(j);
                        String varients=jobj.getString("varient");
                        System.out.println("VARIENTS" + varients);
                        clothing.add(varients);
                    }*/

                }


                /*int length= valuesone.length();
                String varients=valuesone.getString("varients");
                System.out.println("varients"+varients);*/


            } catch (JSONException e) {
                e.printStackTrace();
            }


            for (String s : category) {
                System.out.println("CATEGORY" + s + "CATEGORY SIZE" + category.size());

            }

            for (String ss : image) {
                System.out.println("image" + ss + "image SIZE" + image.size());

            }
           /* MainActivity sa=new MainActivity();
           MainActivity.Imageparse im=sa.new Imageparse();
            im.execute();*/

           /* System.out.println("PARSED IMAGES SIZE" + parsedimages.size());
*/
        }
    }


     public class Imageparse extends AsyncTask<String, String, List<Bitmap> >{

     ProgressDialog prgdialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            prgdialog = new ProgressDialog(MainActivity.this, ProgressDialog.STYLE_SPINNER);
            prgdialog.setMessage("Getting data.....");
            prgdialog.setIndeterminate(false);
            prgdialog.setCancelable(true);
            prgdialog.show();
        }

        @Override
        protected List<Bitmap> doInBackground(String... params) {
            Imageparser ip = new Imageparser();
            System.out.println(image.size()+"IMAGE SIZE  do in background");
            List<String> as=new ArrayList<String>();
            List<Bitmap> array=new ArrayList<Bitmap>();
            array.clear();
           /* image.clear();*/
           // as.add("https://i.imgsafe.org/5cbde6d.png");
            as.add("http://t86.imgup.net/eyewearea04.png");
           /* as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
            as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
            as.add("http://www.androidbegin.com/wp-content/uploads/2013/07/HD-Logo.gif");
*/
            // as.add("https://www.learn2crack.com/wp-content/uploads/2014/04/node-cover-720x340.png");                   ;
            /*Bitmap  s=ip.getJSONfromURL(as.get(0));
            s.toString();
            System.out.println("BITMAP HEIGHT " + s.getHeight() + s.getWidth()+s.getConfig());
            imagesarraybitmap.add(ip.getJSONfromURL(as.get(0)));
            System.out.println("IMAGES ARRAY BITMAP " + "" + imagesarraybitmap.size());*/
            for (int i = 0; i < image.size(); i++) {
            Bitmap  s=ip.getJSONfromURL(image.get(i));
            s.toString();
            System.out.println("BITMAP HEIGHT " + s.getHeight() + s.getWidth()+s.getConfig());
                array.add(ip.getJSONfromURL(image.get(i)));
                System.out.println("IMAGES ARRAY BITMAP " + "" + array.size()+ "    " +image.size());
            }
            return array;
        }


        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(List<Bitmap> bitmaps) {
            super.onPostExecute(bitmaps);
            prgdialog.dismiss();
            System.out.println("ON POST EXECUTE");
            List<Bitmap> parsedimages=new ArrayList<Bitmap>();
            System.out.println("AFTER POST EXECUTE bitmap size" + bitmaps.size());
            parsedimages=bitmaps;
            System.out.println("AFTER POST EXECUTE" + parsedimages.size());

            lv.setAdapter(new Customadapter(MainActivity.this, category, category.size(),parsedimages));

            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent nextpage = new Intent(getApplicationContext(), Nextpage.class);
                    //System.out.println("POSITION VALUE " + position+category.get(0) +"things at location ");
                    nextpageclass = new Nextpage(category, jsonObjectslist, position);
                    TextView textView = (TextView) view.findViewById(R.id.textview);
                    String clickvalue = textView.getText().toString();
                    System.out.println("CLICK VALUE INTENT" + clickvalue);
                    nextpage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    nextpage.putExtra("buttonvalue", clickvalue);
                    getApplicationContext().startActivity(nextpage);
                }
            });
        }
    }

    /*public int count() {

        return image.size() + jsonObjectslist.size() + category.size();
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
