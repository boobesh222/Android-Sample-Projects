package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by boobeshb on 08-04-2016.
 */
public class Recycleviewadapter extends RecyclerView.Adapter<Recycleviewadapter.Myviewholder> {
    ImageView iv;
    TextView textView;
  FragmentManager fragmentManager;
   Context c;

    public Recycleviewadapter(Context c,FragmentManager fragmentManager) {
        this.c = c;
        this.fragmentManager=fragmentManager;
    }

    public  class  Myviewholder extends  RecyclerView.ViewHolder  implements AdapterView.OnItemClickListener{

      public Myviewholder(View itemView) {
           super(itemView);
           iv=(ImageView)itemView.findViewById(R.id.imageview);
           textView = (TextView)itemView.findViewById(R.id.textview);
      }

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String selectedmenu=Retailappmodel.categorynames.get(position);
            new Contentdetails(selectedmenu,c,position);
            Fragment fragment= new Innerlistviewfragment();
            int a = fragmentManager.beginTransaction().replace(R.id.framelayout_main,fragment).addToBackStack(null).commit();
            System.out.println("back stack return value " + a);

            Toast.makeText(c, "selectedmenu" + selectedmenu, Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public Myviewholder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.viewlayout,null);
        return new Myviewholder(v);
    }

    @Override
    public void onBindViewHolder(Myviewholder holder, int position) {

        new Imageparse( c, position,iv,textView).execute();

    }

    @Override
    public int getItemCount() {
       /* return ;*/
       return Retailappmodel.categorynames.size();
    }
}
