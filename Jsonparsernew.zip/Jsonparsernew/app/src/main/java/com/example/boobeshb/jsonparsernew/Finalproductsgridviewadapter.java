package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by boobeshb on 29-03-2016.
 */
public class Finalproductsgridviewadapter extends BaseAdapter {

     Context context;

    public Finalproductsgridviewadapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount()
    {

        System.out.println("getcount " +Retailappmodel.productimages.size());
        return Retailappmodel.productimages.size() ;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {

        LayoutInflater lyi=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View inflatedview=lyi.inflate(R.layout.imagelayout, null);
        ImageView imageview=(ImageView)inflatedview.findViewById(R.id.imagelayout_imageview);
        TextView price =(TextView)inflatedview.findViewById(R.id.price);
        TextView size=(TextView)inflatedview.findViewById(R.id.size);
        imageview.setImageBitmap(Retailappmodel.productimages.get(position));
        price.setText("INR " + Retailappmodel.price.get(position));

        size.setText(Retailappmodel.productsize.get(position));
        return  inflatedview;

    }
}
