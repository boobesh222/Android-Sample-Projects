package com.example.boobeshb.antivirusdesign;

import android.animation.ObjectAnimator;
import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by boobeshb on 19-02-2016.
 */
public class Scanfrag extends Fragment {




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View a= inflater.inflate(R.layout.scan,container,false);
        TextView tv=(TextView)a.findViewById(R.id.textview);
        Date date= new Date();
        date.getTime();
        SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
        tv.setText("Last Scanned " +sdf.format(date.getTime()));
        ProgressBar progressbar=(ProgressBar)a.findViewById(R.id.progressbar);
        ObjectAnimator oa=ObjectAnimator.ofInt(progressbar,"progress",0,500);
        oa.setDuration(50000);
        oa.setInterpolator(new DecelerateInterpolator());
        oa.start();
        return a;
    }
}
