package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.os.Bundle;

import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

/**
 * Created by boobeshb on 24-03-2016.
 */
public class Splashscreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splashscreen);
        try {
            JSONObject jsonObject = new JSONparse(Splashscreen.this).execute().get();
            System.out.println(jsonObject.length()+"SPLASH SCREEN JSON OBJECT LENGTH ");
        }catch (InterruptedException e){
            e.printStackTrace();
        }catch (ExecutionException e){
            e.printStackTrace();
        }
    }
}
