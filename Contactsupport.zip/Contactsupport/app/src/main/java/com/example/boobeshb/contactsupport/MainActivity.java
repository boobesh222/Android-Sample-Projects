package com.example.boobeshb.contactsupport;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Bundle;

import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    Spinner spn;
    Spinner spnone;
    ArrayList<String> names=new ArrayList<String>();
    ArrayList<String> designation=new ArrayList<String>();
    ArrayList<String> des=new ArrayList<>();
    ContentValues cnames=new ContentValues();
    ContentValues cdesignation=new ContentValues();


    public ArrayList<String> getNames() {
        return names;
    }

    public void setNames(ArrayList<String> names) {
        this.names = names;
    }

    public ArrayList<String> getDesignation() {
        return designation;
    }

    public void setDesignation(ArrayList<String> designation) {
        this.designation = designation;
    }

    EditText text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_main);
        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebarlayout);

        spn=(Spinner)findViewById(R.id.main_Spinners);
        text=(EditText)findViewById(R.id.main_Messagebox);
        names.add("john");
        names.add("Bradley");
        names.add("Frank");
        names.add("Oswald");
        names.add("Ronald");

        designation.add("personal trust manager");
        designation.add("regional bank manager");
        designation.add("bank branch manager");
        designation.add("bank director");
        designation.add("loans manager trainee");


        Database dbobj=new Database(getApplicationContext(),null,null,1);
        SQLiteDatabase sdb=dbobj.getWritableDatabase();


        for(int i=0;i<names.size();i++){
            System.out.println(names.get(i)+designation.get(i)+names.size());
            String sql="INSERT INTO PERSONS (NAME,DESIGNATION) VALUES ('"+ names.get(i)+"','"+ designation.get(i)+"')";
            sdb.execSQL(sql);
        }

        names.clear();
        String fetchRecords="SELECT * FROM PERSONS";
        SQLiteDatabase fetchsdb=dbobj.getReadableDatabase();
        System.out.println("fetching records");
        Cursor cs=fetchsdb.rawQuery(fetchRecords, null);

        /* if (cs.moveToFirst()){
            names.clear();
            names.add(cs.moveToNext());
            des.clear();
            des.add(cs.getColumnName(1));
        }*/


        if (cs.moveToFirst()){
            do{
                String name = cs.getString(cs.getColumnIndex("NAME"));
                String desg=cs.getString(cs.getColumnIndex("DESIGNATION"));
                names.add(name);
                des.add(desg);
                System.out.println("values of names and desg added");
            }while(cs.moveToNext());
        }

        for (String s:names){
            System.out.println("names in array list" + s);
        }

        DatabaseUtils udb=new DatabaseUtils();
        udb.dumpCursor(cs);
        System.out.println("fetched");
        cs.close();



        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,names);
        spn.setAdapter(aa);
        spn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int position1 = spn.getSelectedItemPosition();
                String a = names.get(position1);
                Toast.makeText(getApplicationContext(), "you selected" + names.get(position1), Toast.LENGTH_LONG).show();
                text.getText().clear();
                text.setText(a);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        ArrayAdapter aaa=new ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,des);
        spnone=(Spinner)findViewById(R.id.main_Spinnertwo);
        spnone.setAdapter(aaa);
        spnone.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int position1 = spnone.getSelectedItemPosition();
                String a = des.get(position1);
                Toast.makeText(getApplicationContext(), "you selected" + des.get(position1), Toast.LENGTH_LONG).show();
                text.getText().clear();
                text.setText(a);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ImageButton phoneButton=(ImageButton)findViewById(R.id.main_Callbutton);
        phoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent  phonecall =new Intent(Intent.ACTION_CALL);
                phonecall.setData(Uri.parse("tel:91-960-049-8811"));
                startActivity(phonecall);
            }
        });

        ImageButton mail=(ImageButton)findViewById(R.id.main_Mailbutton);
        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent email=new Intent(Intent.ACTION_SEND);
                email.setData(Uri.parse("mailto:"));
                email.setType("plain/text");
                email.putExtra(Intent.EXTRA_CC, "cc");
                email.putExtra(Intent.EXTRA_BCC, "bcc");
                email.putExtra(Intent.EXTRA_SUBJECT, "SAMPLE MAIL ");
                email.putExtra(Intent.EXTRA_TEXT, "MY FIRST MAIL IN ANDROID");
                startActivity(Intent.createChooser(email,"mail"));
                finish();
            }
        });

        ImageButton mesg=(ImageButton)findViewById(R.id.main_messagebutton);
        mesg.setOnClickListener(new View.OnClickListener() {
            String phonenumber="9600498811";
            String mesg="sample mesg";

            @Override
            public void onClick(View v) {
                SmsManager man=SmsManager.getDefault();
                man.sendTextMessage(phonenumber,null,mesg,null,null);
                Toast.makeText(getApplicationContext(),"sms sent",Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
