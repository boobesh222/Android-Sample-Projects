package com.example.boobeshb.youtubescreenexice;

import android.app.Activity;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by boobeshb on 15-02-2016.
 */
public class Next  extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.next);

        ImageView movieposter=(ImageView)findViewById(R.id.next_mainimageview);
        TextView  moviename=(TextView)findViewById(R.id.next_moviename);
        TextView  update=(TextView)findViewById(R.id.next_dateuploaded);
        ImageView likebutton=(ImageView)findViewById(R.id.next_likebutton);
        TextView des=(TextView)findViewById(R.id.next_descrip);

        Date date=new Date();
        SimpleDateFormat a =new SimpleDateFormat();
        String up=a.format(date.getTime());
        Bundle extras=getIntent().getExtras();
        movieposter.setImageResource(extras.getInt("image"));
        moviename.setText( extras.getString("name"));
        des.setText(extras.getString("description"));
        update.setText("Date" + " " + up);
        likebutton.setImageResource(R.drawable.png);



    }
}
