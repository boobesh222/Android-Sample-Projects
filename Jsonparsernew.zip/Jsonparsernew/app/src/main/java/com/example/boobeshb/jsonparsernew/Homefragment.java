package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 23-03-2016.
 */
public class Homefragment extends Fragment {

    String name;

    List<String> image= new ArrayList<String>();

    JSONObject values;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        JSONArray user;
        Bundle b=getArguments();
        String value=b.getString("itemclick");
        System.out.println(value+"ITEM CLICK VALUE");
        Retailappmodel retailappmodel=new Retailappmodel();
        System.out.println("HOME FRAGMENT JSON OBJECT " + retailappmodel.getJsonObject());


       /* if (jsonObject.length()==0){
            System.out.println("JSON OBJECT SIZE IS GREATED THAN ZERO");
        }else {
            System.out.println("SIZE 0");
        }*/

        List<JSONObject> jsonObjectslist;

        try {

            user =retailappmodel.getJsonObject().getJSONArray("Men");
            int nodelength = user.length();
            System.out.println(nodelength + "nodelength");
            image.clear();
            jsonObjectslist = new ArrayList<JSONObject>();
            for (int i = 0; i < nodelength; i++) {

                values = user.getJSONObject(i);
                JSONArray listNames = values.names();
                   /* JSONArray valuesone=values.getJSONArray("1");
                    System.out.println(listNames.length()+"LIST NAMES LENGTH" +listNames.toString());
                    System.out.println(i + "i value");*/
                String category1 = values.getString("category");
                String images = values.getString("images");
                image.add(images);
                jsonObjectslist.add(values);




            }

           for(String s:image){
                System.out.println(s+"IMAGES WEBSITES");
           }



        } catch (JSONException e) {
            e.printStackTrace();
        }

        return inflater.inflate(R.layout.fragmentlayout,null);
    }
}
