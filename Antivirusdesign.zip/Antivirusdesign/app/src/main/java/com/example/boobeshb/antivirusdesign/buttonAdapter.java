package com.example.boobeshb.antivirusdesign;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;

import java.util.ArrayList;

/**
 * Created by boobeshb on 18-02-2016.
 */
public class buttonAdapter extends BaseAdapter {
    Context cc;

    int images[]={R.drawable.antivirussmall,R.drawable.callmanagersmall,R.drawable.pcsmall,R.drawable.antitheftsmall,R.drawable.backupsmall};


    public buttonAdapter(Context c) {
        cc = c;
    }

    @Override
    public int getCount() {
        System.out.println("COUNT VALUE"+ images.length);
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
          Button button;
        LayoutInflater inf=(LayoutInflater)cc.getSystemService(cc.LAYOUT_INFLATER_SERVICE);
        View buttonview ;

                   /*button=new Button(cc);
          //  button.setLayoutParams(new GridView.LayoutParams(100, 100));
              button.setBackgroundResource(R.drawable.antivirus);

*/
              System.out.println("POSITION VALUE" +position);
              buttonview=inf.inflate(R.layout.buttonlayout,null);
              Button one=(Button)buttonview.findViewById(R.id.buttonlay_buttonone);
              /*one.setLayoutParams(new GridView.LayoutParams(25,25));*/
              one.setBackgroundResource(images[position]);
              return buttonview;



    }


    public int  buttons() {
        int count=5;
        return  count;
    }
}
