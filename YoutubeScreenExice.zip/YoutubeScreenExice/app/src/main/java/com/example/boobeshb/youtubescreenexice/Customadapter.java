package com.example.boobeshb.youtubescreenexice;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.FieldPosition;
import java.util.zip.Inflater;

/**
 * Created by boobeshb on 08-02-2016.
 */
public class Customadapter extends BaseAdapter {
    int [] listImages;
    String [] listImagesName;

    int c = 0;
    Context context;
    LayoutInflater inflater =null;

    public Customadapter(MainActivity main,String [] names,int [] images) {
        context=main;
        listImagesName=names;
        listImages=images;

        inflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        System.out.println("inside cons custom adapter");
    }

    @Override
    public int getCount() {
        System.out.println("get count" + listImagesName.length);
        return listImagesName.length;
    }

    @Override
    public Object getItem(int position) {
        System.out.println("get item position value" + position);

        return position;
    }

    @Override
    public long getItemId(int position) {
        System.out.println("getItemID" + position);
        return position;
    }

         TextView imagesname;
         ImageView images;


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //c=c+1;
        View finalView=inflater.inflate(R.layout.listviewlayout,null);
        System.out.println("inflated");
        images=(ImageView)finalView.findViewById(R.id.listviewlayout_Imageview);
        imagesname=(TextView)finalView.findViewById(R.id.listviewlayout_Textview);

        images.setImageResource(listImages[position]);
        imagesname.setText(listImagesName[position]);
        return finalView;

    }



}
