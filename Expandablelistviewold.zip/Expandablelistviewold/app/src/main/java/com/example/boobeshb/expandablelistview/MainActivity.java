package com.example.boobeshb.expandablelistview;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends Activity {

    Expandablelistadapter eladapter;
    ExpandableListView listviewex;
    List<String> header=new ArrayList<String>();
    HashMap<String,List<String>> map=new HashMap<String,List<String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listviewex=(ExpandableListView)findViewById(R.id.main_exlistview);
        preparedata();

        eladapter=new Expandablelistadapter(getApplicationContext(),header,map);
        listviewex.setAdapter(eladapter);

        listviewex.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                TextView ed = (TextView) v.findViewById(R.id.listitem_edittext);
                ed.setFocusable(false);
                ed.getText();
                System.out.println("EDITTEXT VALUE" + ed.getText());
                Toast.makeText(MainActivity.this, ed.getText(), Toast.LENGTH_LONG).show();
                return true;
            }
        });



    }

    public void preparedata(){
        header.add("header1");
        header.add("header2");
        header.add("header3");

        List<String> movies=new ArrayList<String>();
        movies.add("conjuring");
        movies.add("spiderman");
        movies.add("harrypotter");
        List<String> cartoons=new ArrayList<String>();
        cartoons.add("tom and jerry");
        cartoons.add("justice league");
        List<String> podcasts=new ArrayList<String>();
        podcasts.add("Stations1");
        podcasts.add("jazz");
        podcasts.add("pop");
        podcasts.add("western");

        map.put(header.get(0), movies);
        map.put(header.get(1), cartoons);
        map.put(header.get(2),podcasts);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
