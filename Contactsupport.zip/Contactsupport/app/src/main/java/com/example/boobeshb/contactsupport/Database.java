package com.example.boobeshb.contactsupport;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by boobeshb on 15-02-2016.
 */
public class Database extends SQLiteOpenHelper {

    public Database(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String deleteTable="DROP TABLE IF EXISTS PERSONS";
        db.execSQL(deleteTable);
        String createTable="CREATE TABLE PERSONS (NAME VARCHAR(50),DESIGNATION VARCHAR(50))";
        db.execSQL(createTable);
        System.out.println("TABLE CREATED");
        /*ContentValues a=new ContentValues();
        System.out.println("cv CREATED");
        a.put("NAME", "sdfn");
        db.insert("PERSONS", null, a);
        System.out.println("xxxxxxxxxxx");*/


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String deleteTable="DROP TABLE IF EXISTS PERSONS";
        db.execSQL(deleteTable);
        onCreate(db);
    }
}
