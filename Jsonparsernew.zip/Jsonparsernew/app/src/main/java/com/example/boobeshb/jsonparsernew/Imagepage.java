package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 10-03-2016.
 */
public class Imagepage extends Activity {
    public  static   List<Bitmap> imageslist=new ArrayList<Bitmap>();
    public  static  List<Integer> pricelist=new ArrayList<Integer>();
    public static List<String> sizelist=new ArrayList<String>();

    public Imagepage() {
    }

    public Imagepage(List<Bitmap> bitmapList,List<Integer> p,List<String> s) {
        imageslist=bitmapList;
        pricelist=p;
        sizelist=s;
        System.out.println("IMAGES LIST SIZE= " +imageslist.size());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.finalproducts);

        GridView finalproducts=(GridView)findViewById(R.id.finalproducts_gridview);
        finalproducts.setAdapter(new Finalproductsadapter(imageslist,Imagepage.this,pricelist,sizelist));
        finalproducts.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
/*
                Toast.makeText(Imagepage.this, "clicked on position" + position, Toast.LENGTH_SHORT).show();
*/              Prdpagedetails obj=new Prdpagedetails(imageslist,pricelist,sizelist);
                Intent productpage=new Intent(Imagepage.this,Prdpagedetails.class);
                productpage.putExtra("POSITIONVALUE",position);
                productpage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(productpage);
            }
        });
    }



}
