package com.example.boobeshb.antivirusdesign;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by boobeshb on 19-02-2016.
 */
public class detectedfiles extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View a= inflater.inflate(R.layout.detectedfiles, container, false);
        return  a;
    }
}
