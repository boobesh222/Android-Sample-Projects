package com.example.boobeshb.layoutexample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button linearButton1=(Button)findViewById(R.id.button);
        Button linearButton2=(Button)findViewById(R.id.button2);
        Button linearButton3=(Button)findViewById(R.id.button3);
        Button linearButton4=(Button)findViewById(R.id.button4);

        linearButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"BUTTON 1 CLICKED",Toast.LENGTH_LONG).show();
                Intent button1=new Intent(getApplicationContext(),Buttonone.class);
                startActivity(button1);
            }
        });

        linearButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"BUTTON 2 CLICKED",Toast.LENGTH_LONG).show();
                Intent button2=new Intent(getApplicationContext(),Buttontwo.class);
                startActivity(button2);
            }
        });

        linearButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"BUTTON 1 HORIZON CLICKED",Toast.LENGTH_LONG).show();
                Intent button3=new Intent(getApplicationContext(),foods.class);
                startActivity(button3);
            }
        });

        linearButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "BUTTON 2 HORIZON CLICKED", Toast.LENGTH_LONG).show();
                Intent button4 = new Intent(getApplicationContext(), Vehicles.class);
                startActivity(button4);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
