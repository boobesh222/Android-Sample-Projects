package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 04-03-2016.
 */
public class Nextpage extends Activity {
    public static List<String> categorylist =new ArrayList<String>();
    public static  List<JSONObject> jsonobjlist=new ArrayList<JSONObject>();
    public static int position;
    public static List<String> innercategories=new ArrayList<String>();
    public static List<JSONArray> subcategoriesarray=new ArrayList<>();
    public static List<String> subcat = new ArrayList<String>();
    public static List<Bitmap> bitmaparray = new ArrayList<Bitmap>();
    public static List<String> sizearray=new ArrayList<String>();
    public static List<Integer> pricearray=new ArrayList<Integer>();

    public static  JSONArray jo;
      /*  List neww =new ArrayList();*/


    public Nextpage() {

    }

    public Nextpage(List<String> x,List<JSONObject> y,int p){
        innercategories.clear();
        categorylist=x;
        jsonobjlist=y;
        position=p;
        System.out.println("Sizes" +categorylist.size()+jsonobjlist.size());

       /* for(JSONObject jb:jsonobjlist){
            System.out.println("JSON OBJECTS NAME" + jb.names());

        }*/
        /*  for(int i=0;i<jsonobjlist.size();i++){*/


        //}


        try {
            System.out.println(jsonobjlist.get(position).getString("1") + "TRY BLOCK");
            JSONObject array=jsonobjlist.get(position);

            JSONArray nameslist=array.names();


            JSONArray names=array.getJSONArray("1");

            int arraylength=names.length();
            subcategoriesarray.clear();
            for(int j=0;j<names.length();j++){
                System.out.println("JSON ARRAY" + names.getJSONObject(j));
                JSONObject obj=names.getJSONObject(j);
                System.out.println(obj.getString("varient") + "FINAL ITEMS LIST");
                System.out.println(obj.getString("subcategories") + "SUB CATEGORIES");
                 jo=obj.getJSONArray("subcategories");

                System.out.println("subcat jo length" + j + jo.length());
                subcategoriesarray.add(jo);
                /*System.out.println(" list of web links for images" + jo.getString("list"));*//*
                */innercategories.add(obj.getString("varient"));

            }

            for(int w=0;w<subcategoriesarray.size();w++){
                System.out.println("FOR LOOP JSON ARRAY"+subcategoriesarray.get(w));
                JSONArray sdf=subcategoriesarray.get(w);
                for(int z=0;z<sdf.length();z++){
                    System.out.println(sdf.getJSONObject(z).getString("list") + "   " +  "SUBCATEGORIES JSON OBJECTS" + z);

                }
            }

            // System.out.println(array.getString("varient")+"VARIENTS FOR OPTIONS");
            for (int i=0;i<array.length();i++){
                System.out.println("FOR LOOP" +array.names());
            }

            for(String s:innercategories){
                System.out.println(s+"inner cat");

            }

        }catch (JSONException e){
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menus);

        /*ListView lv=(ListView)findViewById(R.id.menus_listviewone);
        Bundle bundle=getIntent().getExtras();
        String value=bundle.getString("buttonvalue");
        System.out.println("CLICK VALUE " + value);

         lv.setAdapter(new Innerlistview(Nextpage.this, innercategories));

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                JSONArray sdf = subcategoriesarray.get(position);
                subcat.clear();
                for (int z = 0; z < sdf.length(); z++) {
                    try {
                        System.out.println(sdf.getJSONObject(z).getString("list") + "   " + "SUBCATEGORIES JSON OBJECTS" + z);
                        subcat.add(sdf.getJSONObject(z).getString("list"));
                        pricearray.add(sdf.getJSONObject(z).getInt("price"));
                        sizearray.add(sdf.getJSONObject(z).getString("sizes"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                System.out.println("SUB CAT LIST SIZE" + subcat.size() + " PRICE AND SIZE" +pricearray.size()+ "    "+sizearray.size() );

                Subcategoriesimageparse sip=new Subcategoriesimageparse();
                sip.execute();

            }
        });
        System.out.println("ADAPTER SETTED " + value);
*/
    }

    class Subcategoriesimageparse extends AsyncTask<String, String, List<Bitmap>> {
          ProgressDialog prgdialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            prgdialog = new ProgressDialog(Nextpage.this, ProgressDialog.STYLE_SPINNER);
            prgdialog.setMessage("loading.....");
            prgdialog.setIndeterminate(false);
            prgdialog.setCancelable(true);
            prgdialog.show();
        }

        @Override
        protected List<Bitmap> doInBackground(String... params) {
            Imageparser imp = new Imageparser();
            Bitmap s;
            bitmaparray.clear();
            for (int i = 0; i < subcat.size(); i++) {
                s = imp.getJSONfromURL(subcat.get(i));
                bitmaparray.add(s);
            }
            return bitmaparray;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(List<Bitmap> bitmaps) {
            super.onPostExecute(bitmaps);
            prgdialog.dismiss();
            System.out.println("ON POST EXECUTE GRID ADAPTER " +bitmaps.size());
            Intent Imagespage=new Intent(getApplicationContext(),Imagepage.class);
            Imagepage Imagepage=new Imagepage(bitmaps,pricearray,sizearray);
            Imagespage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getApplicationContext().startActivity(Imagespage);
        }


    }


}


