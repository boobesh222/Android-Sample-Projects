package com.example.boobeshb.appinvoking;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Switch;
import android.widget.Toast;

/**
 * Created by boobeshb on 16-02-2016.
 */
public class Callreceiver extends BroadcastReceiver {



    @Override
    public void onReceive(final Context context, final Intent intent) {
        final String phonenumber="9600498811";

        TelephonyManager tm=(TelephonyManager)context.getSystemService(context.TELEPHONY_SERVICE);
        tm.listen(new PhoneStateListener(){
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);
                SharedPreferences sp=context.getSharedPreferences("numbers",Context.MODE_PRIVATE);
                SharedPreferences.Editor se =sp.edit();
                switch (state) {

                        case (TelephonyManager.CALL_STATE_RINGING):
                            System.out.println("ringing state" + incomingNumber);

                               // Toast.makeText(context, "ringing " + incomingNumber, Toast.LENGTH_SHORT).show();

                                se.putString("inphonenumber", incomingNumber);
                                se.commit();
                            String in=sp.getString("inphonenumber","");
                            Intent intent = new Intent(context, callinterface.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("phone", in);
                            context.startActivity(intent);

                               //  Toast.makeText(context,incomingNumber,Toast.LENGTH_LONG).show();
                            break;

                        case (TelephonyManager.CALL_STATE_IDLE):
                            System.out.println("idle state " + incomingNumber);
                            Toast.makeText(context, "state idle :::" + incomingNumber, Toast.LENGTH_SHORT).show();
                            /*String in=sp.getString("inphonenumber","");
                            Intent intent = new Intent(context, callinterface.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("phone", in);
                            context.startActivity(intent);
                            callinterface c=new callinterface();
                            c.finish();*/
                            break;

                        case (TelephonyManager.CALL_STATE_OFFHOOK):
                              String inh=sp.getString("inphonenumber","");
                             // String ph="9600498811";
                             // Toast.makeText(context,"in value" + in +"phone number value" + phonenumber,Toast.LENGTH_LONG ).show();
                            if ((inh).equals(phonenumber)) {
                               // System.out.println("off hook state " + incomingNumber);
                               // Toast.makeText(context, "off hook" + in + "", Toast.LENGTH_SHORT).show();
                                Intent intenty = new Intent(context, callinterface.class);
                                intenty.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intenty.putExtra("phone", inh);
                                context.startActivity(intenty);

                            }
                            break;
                    }

                }

        },PhoneStateListener.LISTEN_CALL_STATE);



    }

}



/*
if (phonenumber.equals(incomingNumber)) {
        System.out.println("off hook state " + incomingNumber);
        Toast.makeText(context, "off hook" + incomingNumber + "", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(context, callinterface.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("phone", incomingNumber);
        context.startActivity(intent);

        }*/

/*Intent intent=new Intent(context,callinterface.class);
                             intent.putExtra("ph",incomingNumber);
                            context.startActivity(intent);*/

 /*final Context d=context;
        TelephonyManager tm= (TelephonyManager)context.getSystemService(context.TELEPHONY_SERVICE);
        tm.listen(new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);
                System.out.println("phone number is " + incomingNumber);

                phonenumber = incomingNumber;
                String verification="9600498811";
                //Toast.makeText(context,"phone number maches condition",Toast.LENGTH_LONG).show();
                System.out.println("PHONENUMBER " + phonenumber);
                if(phonenumber.equals(verification)){
                    MainActivity a=new MainActivity();
                    Context cc= a.getC();
                    Toast.makeText(d,"phone number maches condition",Toast.LENGTH_LONG).show();
                    System.out.println("AFTER TOAST ");
                    PackageManager pm=context.getPackageManager();
                    Intent aa=new Intent();
                    aa=pm.getLaunchIntentForPackage("com.example.boobeshb.youtubescreenexice");
                    aa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(aa);
                    PackageInfo pi=context.getPackageManager().getPackageInfo("com.example.boobeshb.youtubescreenexice",);
                    *//*Intent launchapp=new Intent();
                    launchapp.setComponent(new ComponentName("com.example.boobeshb.youtubescreenexice",".MainActivity"));
                    launchapp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    d.startActivity(launchapp);*//*
                }
                else{
                    Toast.makeText(context,"call from "+ phonenumber+ "number not mached",Toast.LENGTH_LONG ).show();
                }
            }
        }, PhoneStateListener.LISTEN_CALL_STATE);


    }*/