package com.example.boobeshb.jsonparsernew;

import android.graphics.Bitmap;

import java.util.List;

/**
 * Created by boobeshb on 22-03-2016.
 */
public interface jsonparsinginterface {

    public List<Bitmap>  processresult(List<Bitmap> a);
}
