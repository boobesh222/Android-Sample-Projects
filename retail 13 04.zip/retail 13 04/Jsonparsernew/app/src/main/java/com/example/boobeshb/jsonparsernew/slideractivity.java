package com.example.boobeshb.jsonparsernew;

import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class slideractivity extends ActionBarActivity {

    int clickposition;
    DrawerLayout drawerLayout;
    ListView drawerlistview;
    ActionBarDrawerToggle mdrawertoggle;
    CharSequence mDrawerTitle;
    CharSequence mTitle;
    CharSequence appname="Retailapp";
    String[] navmenutitles = {"Home","men", "women", "kids"};
    int[] navicons = {R.drawable.men, R.drawable.womens, R.drawable.kids};
    TypedArray navmenuicons;
    ArrayList<navdrawerclass> navdrawerlist;
    Navlistadapter navlistadapter;
    //String Url="http://www.json-generator.com/api/json/get/ctYjYOWdvm?indent=2";
    String Url = "http://www.json-generator.com/api/json/get/bSrsNpHOgi?indent=2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.slider_main);
/*
        Toast.makeText(slideractivity.this, "oncreate ", Toast.LENGTH_LONG).show();
*/
/*
        new fetchJson().execute();
*/

        mDrawerTitle = mTitle = getTitle();
        navmenuicons = getResources().obtainTypedArray(R.array.nav_drawer_icons);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayout_main);
        drawerlistview = (ListView) findViewById(R.id.listview_main);
        System.out.println(navmenuicons.toString());
        navdrawerlist = new ArrayList<navdrawerclass>();
        navdrawerlist.add(new navdrawerclass(navmenutitles[0], navmenuicons.getResourceId(0, -1)));
        navdrawerlist.add(new navdrawerclass(navmenutitles[1], navmenuicons.getResourceId(1, -1)));
        navdrawerlist.add(new navdrawerclass(navmenutitles[2], navmenuicons.getResourceId(2, -1)));
        navdrawerlist.add(new navdrawerclass(navmenutitles[3], navmenuicons.getResourceId(3, -1)));

        drawerlistview.setOnItemClickListener(new slideMenuClickListener());

        navmenuicons.recycle();
/*
        Toast.makeText(slideractivity.this, "Typed array recycled", Toast.LENGTH_LONG).show();
*/

        navlistadapter = new Navlistadapter(getApplicationContext(), navdrawerlist);
        drawerlistview.setAdapter(navlistadapter);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mdrawertoggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.draweropen, R.string.drawerclosed) {

            public void onDrawerClosed(View view) {
                getSupportActionBar().setTitle(mTitle);
                // calling onPrepareOptionsMenu() to show action bar icons
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                getSupportActionBar().setTitle(mDrawerTitle);
                // calling onPrepareOptionsMenu() to hide action bar icons
                invalidateOptionsMenu();
            }
        };


        drawerLayout.setDrawerListener(mdrawertoggle);

        if (savedInstanceState == null) {

            Toast.makeText(slideractivity.this, "savedinstance== null", Toast.LENGTH_LONG).show();
         /*   setTitle(appname);*/
            displayview(0);



        }


    }

    private class slideMenuClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            clickposition=position;
            System.out.println("SLIDEMENUCLICK BEFORE DISPLAY VIEW");
            Toast.makeText(slideractivity.this, "slidermenuclicklistener", Toast.LENGTH_LONG).show();
            drawerLayout.closeDrawer(drawerlistview);
            displayview(position);
        }
    }


    public void displayview(int position) {
        final int  posi=position;
        Fragment fragment = null;
        Bundle bundle=new Bundle();
        bundle.putString("menu",navdrawerlist.get(position).getTitle());
        switch (position) {
            case 0:
                fragment=new Startfragment();
                System.out.println(fragment.getTag() + "FRAGMENT TAG");
                break;
            case 1:
                fragment = new Homefragment();
                System.out.println("CASE 0");
                break;
            case 2:
                fragment = new mensfragment();
                fragment.setArguments(bundle);
/*
                getFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
*/
                break;
            case 3:
                fragment = new kidsfrag();
            default:
                break;
        }

        if (fragment != null) {


            getFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

            int a= getFragmentManager().beginTransaction().replace(R.id.framelayout_main, fragment, null).addToBackStack(null).commit();
            System.out.println("back stack return value " +a);
            getFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
                @Override
                public void onBackStackChanged() {
                    Toast.makeText(slideractivity.this, "add on back stack", Toast.LENGTH_SHORT).show();
                }
            });
            drawerlistview.setItemChecked(position, true);
            drawerlistview.setSelection(position);
/*
            Toast.makeText(slideractivity.this, "fragment!=null before setting title", Toast.LENGTH_SHORT).show();
*/
            setTitle(navmenutitles[position]);
/*
            Toast.makeText(slideractivity.this, "" + navmenutitles[position], Toast.LENGTH_LONG).show();
*/

        }


    }



    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        System.out.println("SET TITLE ");
        getSupportActionBar().setTitle(mTitle);
/*
        Toast.makeText(slideractivity.this, "@ OVERRIDED SET TITLES" + mTitle , Toast.LENGTH_LONG).show();
*/


    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
/*
        Toast.makeText(slideractivity.this, " ON POST CREATE", Toast.LENGTH_LONG).show();
*/
        mdrawertoggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mdrawertoggle.onConfigurationChanged(newConfig);
/*
        Toast.makeText(slideractivity.this, "ONCONFIGURATION  CHANGED", Toast.LENGTH_LONG).show();
*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
/*
        Toast.makeText(slideractivity.this, "ONCREATE OPTIONS MENU", Toast.LENGTH_LONG).show();
*/
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (mdrawertoggle.onOptionsItemSelected(item)) {
/*
            Toast.makeText(slideractivity.this, "ONOPTIONS SELECTED IF LOOP" + item, Toast.LENGTH_LONG).show();
*/
            return true;
        }

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
/*
            Toast.makeText(slideractivity.this, "id value" + id, Toast.LENGTH_LONG).show();
*/
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        boolean drau = drawerLayout.isDrawerOpen(drawerlistview);
        menu.findItem(R.id.action_settings).setVisible(!drau);
/*
        Toast.makeText(slideractivity.this, "ONPREPAREOPTIONSMENU ", Toast.LENGTH_LONG).show();
*/      return super.onPrepareOptionsMenu(menu);
    }


    /* public class JSONparse extends AsyncTask<String, String, JSONObject> {

        String Url = "http://www.json-generator.com/api/json/get/bSrsNpHOgi?indent=2";

        ProgressDialog prgdialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


           *//* Fragment sjhd=new listviewFrag();*//*

            prgdialog = new ProgressDialog(slideractivity.this, ProgressDialog.STYLE_SPINNER);
            prgdialog.setMessage("Getting data.....");
            prgdialog.setIndeterminate(false);
            prgdialog.setCancelable(true);
            prgdialog.show();
        }


        @Override
        protected JSONObject doInBackground(String... params) {
            Jsonparser parser = new Jsonparser();
            JSONObject object = parser.getJSONfromURL(Url);
            return object;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);

            prgdialog.dismiss();

        }

    }*/

    /*@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int count=getFragmentManager().getBackStackEntryCount();
        if(count==1 && keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0){
            final Dialog dialog=new Dialog(slideractivity.this);
            dialog.setContentView(R.layout.dialogbox);
            dialog.setTitle("confirm !");
            dialog.show();
            Button b=(Button)dialog.findViewById(R.id.yesbutton);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });

            Button no=(Button)dialog.findViewById(R.id.nobutton);
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        }

        return super.onKeyDown(keyCode, event);
    }
*/


    @Override
    public void onBackPressed() {

        int count=getFragmentManager().getBackStackEntryCount();
        Toast.makeText(slideractivity.this, "count " + count, Toast.LENGTH_SHORT).show();

        if (count==0){

            final Dialog dialog=new Dialog(slideractivity.this);
            dialog.setContentView(R.layout.dialogbox);
            dialog.setTitle("confirm !");
            dialog.show();
            Button b=(Button)dialog.findViewById(R.id.yesbutton);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });

            Button no=(Button)dialog.findViewById(R.id.nobutton);
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            System.out.println("count " + count);
        }
        else if(count == 1 ) {

            if(getSupportActionBar().getTitle()!= "Home"){
                getFragmentManager().popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Fragment frag=new Startfragment();
                int a= getFragmentManager().beginTransaction().replace(R.id.framelayout_main, frag, null).commit();
                System.out.println("back stack return value " + a);
                drawerlistview.setItemChecked(0, true);
                drawerlistview.setSelection(0);
                setTitle(navmenutitles[0]);
            }else {
                final Dialog dialog = new Dialog(slideractivity.this);
                dialog.setContentView(R.layout.dialogbox);
                dialog.setTitle("confirm !");
                dialog.show();
                Button b = (Button) dialog.findViewById(R.id.yesbutton);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        finish();
                    }
                });

                Button no = (Button) dialog.findViewById(R.id.nobutton);
                no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
            }
           //  getFragmentManager().popBackStackImmediate("homefragment", FragmentManager.POP_BACK_STACK_INCLUSIVE);





/*
            Toast.makeText(slideractivity.this, "fragment!=null before setting title", Toast.LENGTH_SHORT).show();
*/
/*
            Toast.makeText(slideractivity.this, "" + navmenutitles[position], Toast.LENGTH_LONG).show();
*/

/*
            getFragmentManager().popBackStack(1, FragmentManager.POP_BACK_STACK_INCLUSIVE);
*/
            /*final Dialog dialog=new Dialog(slideractivity.this);
            dialog.setContentView(R.layout.dialogbox);
            dialog.setTitle("confirm !");
            dialog.show();
            Button b=(Button)dialog.findViewById(R.id.yesbutton);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    finish();
                }
            });

            Button no=(Button)dialog.findViewById(R.id.nobutton);
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });*/
        }else{
            getFragmentManager().popBackStackImmediate();
        }

    }


}


/*else if(count == 1 ){
             getFragmentManager().popBackStack(2,FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }*/