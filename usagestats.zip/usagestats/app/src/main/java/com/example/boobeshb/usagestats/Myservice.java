package com.example.boobeshb.usagestats;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by boobeshb on 01-04-2016.
 */
public class Myservice extends Service {
     long startedtime;
     long endtime;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(Myservice.this, "SERVICE STARTED", Toast.LENGTH_SHORT);
        System.out.println(" ON START COMMAND");

        PackageManager pm=getPackageManager();
        List<PackageInfo> installedpackages=pm.getInstalledPackages(PackageManager.GET_META_DATA);
        for(PackageInfo p:installedpackages){
              System.out.println("info on packages" + p.packageName+ " receivers"+p.receivers);
        }

        Intent intents =getPackageManager().getLaunchIntentForPackage("com.example.boobeshb.xmlparsing");
        intents.addCategory(Intent.CATEGORY_LAUNCHER);
        Date date=new Date();
        startedtime=date.getTime();
        System.out.println("Started time " + date.getTime());
        startActivity(intents);
        Timer timer=new Timer();
        timer.scheduleAtFixedRate(new checkrunnungapps(),new Date(),60000);


        return START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(Myservice.this, "SERVICE STOPPED", Toast.LENGTH_SHORT).show();
    }


    class checkrunnungapps extends TimerTask{
        ActivityManager  am=(ActivityManager)getSystemService(Myservice.this.ACTIVITY_SERVICE);

        @Override
        public void run() {


            List<ActivityManager.RunningAppProcessInfo> runningprocess=am.getRunningAppProcesses();
            System.out.println(runningprocess.get(0)+"RUNNING ACTIVITY");
            Boolean runningprocesses= runningprocess.equals("com.example.boobeshb.xmlparsing");
            System.out.println("running or not " + runningprocess);
            for(ActivityManager.RunningAppProcessInfo r:runningprocess){
                System.out.println("FOR LOOP  "+ r.processName);
                if(r.processName.equals("com.example.boobeshb.xmlparsing")){
                    System.out.println(" YOUR APP RUNNING ");
                }else if(r.processName != "com.example.boobeshb.xmlparsing"){
                    Date d=new Date();
                    endtime=d.getTime();
                    System.out.println("end time " +d.getTime());
                    System.out.println("ELAPSED TIME SINCE STARTED" + (endtime-startedtime));
                }

            }

        }
    }
}
