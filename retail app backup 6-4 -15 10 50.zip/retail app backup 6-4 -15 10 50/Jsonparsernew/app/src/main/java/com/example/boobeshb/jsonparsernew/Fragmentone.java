package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by boobeshb on 18-03-2016.
 */
public class Fragmentone extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v=inflater.inflate(R.layout.menus,null);
        System.out.println("onCreateView");
        return v ;
    }
}
