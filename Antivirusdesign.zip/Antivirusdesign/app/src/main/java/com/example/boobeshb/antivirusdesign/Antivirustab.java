package com.example.boobeshb.antivirusdesign;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Window;

/**
 * Created by boobeshb on 19-02-2016.
 */
public class Antivirustab extends Activity {

    ActionBar.Tab scan ,detectedfiles,detectedApps;
    Fragment scanfrag=new Scanfrag();
    Fragment detectedfilesfrag=new detectedfiles();
    Fragment detectedappsfrag=new detectedapps();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);*/
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        setContentView(R.layout.antivirustabs);
       /* getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.antivirustitle);*/


        ActionBar actionBar=getActionBar();
        actionBar.setCustomView(R.layout.antivirustitle);
        actionBar.setDisplayOptions(actionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(false);
        actionBar.setDisplayShowHomeEnabled(false);
       // actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setNavigationMode(actionBar.NAVIGATION_MODE_TABS);
        scan=actionBar.newTab().setText("SCAN");
        detectedfiles=actionBar.newTab().setText("detectedfiles");
        detectedApps=actionBar.newTab().setText("detectedapps");
        scan.setTabListener(new Tablisteners(scanfrag));
        detectedfiles.setTabListener(new Tablisteners(detectedfilesfrag));
        detectedApps.setTabListener(new Tablisteners(detectedappsfrag));
        actionBar.addTab(scan);
        actionBar.addTab(detectedfiles);
        actionBar.addTab(detectedApps);

    }


}
