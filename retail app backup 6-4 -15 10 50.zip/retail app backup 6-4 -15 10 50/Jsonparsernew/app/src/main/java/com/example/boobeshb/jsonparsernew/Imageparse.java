package com.example.boobeshb.jsonparsernew;

import android.animation.BidirectionalTypeConverter;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 28-03-2016.
 */
public class Imageparse extends AsyncTask<String, String, Bitmap  > {

    ProgressDialog prgdialog;
    Context c;
    int position;
    ImageView iv;
    TextView tv;

    public Imageparse(Context context,int position,ImageView iv,TextView tv) {
        c = context;
        this.position=position;
        this.iv=iv;
        this.tv=tv;
        System.out.println("IMAGE PARSE CONSTRUCTOR ");
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

       /* prgdialog = new ProgressDialog(c, ProgressDialog.STYLE_SPINNER);
        prgdialog.setMessage("Getting data.....");
        prgdialog.setIndeterminate(false);
        prgdialog.setCancelable(true);
        prgdialog.show();*/

    }

    @Override
    protected Bitmap doInBackground(String... params) {
        Imageparser ip = new Imageparser();
        System.out.println(Retailappmodel.image.size() + "IMAGE SIZE  do in background");

        List<Bitmap> array = new ArrayList<Bitmap>();
        Retailappmodel.bitmapimages.clear();
        array.clear();
        Bitmap s=ip.getJSONfromURL(Retailappmodel.image.get(position));
        /*for (int i = 0; i < Retailappmodel.image.size(); i++) {
            array.add(ip.getJSONfromURL(Retailappmodel.image.get(i)));
        }

        System.out.println("IMAGES ARRAY BITMAP" + "" + array.size() + "    ");
        for(Bitmap s:array){
            System.out.println(s.toString()+ "for loop bitmaps ");
        }

        Retailappmodel.bitmapimages=array;
        System.out.println(Retailappmodel.bitmapimages.size()+"BIT MAPS SIZE DO IN BACKGROUND ");
        return array;
*/        return s;
    }


    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(Bitmap bitmaps) {
         super.onPostExecute(bitmaps);
        Retailappmodel.bitmapimages.clear();
        Retailappmodel.bitmapimages.add(bitmaps);
        iv.setImageBitmap(bitmaps);
        tv.setText(Retailappmodel.categorynames.get(position));
    }

}
