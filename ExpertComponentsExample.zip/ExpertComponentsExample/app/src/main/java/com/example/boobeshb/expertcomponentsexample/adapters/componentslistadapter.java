package com.example.boobeshb.expertcomponentsexample.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.boobeshb.expertcomponentsexample.R;
import com.example.boobeshb.expertcomponentsexample.classes.Specialcomponents;

/**
 * Created by boobeshb on 03-05-2016.
 */
public class componentslistadapter extends BaseAdapter {

    @Override
    public int getCount() {
        return Specialcomponents.componentsname.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.componentsnameview,null);
        TextView textView=(TextView)v.findViewById(R.id.specialcomponentsname);
        textView.setText(Specialcomponents.componentsname.get(position));
        return v;
    }
}
