package com.example.boobeshb.mapsexercise;

import android.app.FragmentManager;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.IllegalFormatCodePointException;
import java.util.List;

public class MainActivity extends ActionBarActivity {

    static final LatLng sensiple = new LatLng(12.81885242, 80.21494746);
    GoogleMap googlemap;
        BitmapDescriptor icon;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    List<Integer> sno=new ArrayList<Integer>();
    List<String> name=new ArrayList<String>();
    List<Double> latitude=new ArrayList<Double>();
    List<Double> longitude=new ArrayList<Double>();
    List<Integer> location=new ArrayList<Integer>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbhelper dbhelper=new dbhelper(getApplicationContext(),null,null,1);
        SQLiteDatabase sq=dbhelper.getWritableDatabase();

        for(int i=1;i<10;i++){
            sno.add(i);
        }

        name.add("mexico");
        name.add("beijing");
        name.add("manila");
        name.add("Dhaka");
        name.add("Jakarta");
        name.add("Tokyo");
        name.add("Taipei");
        name.add("Bogotá");
        name.add("Hong Kong");


        latitude.add(19.428472427036);
        latitude.add(39.9074977414405);
        latitude.add(14.6042);
        latitude.add(23.710395616597037);
        latitude.add(-6.214623197035775);
        latitude.add(35.6895);
        latitude.add(25.047763);
        latitude.add(4.609705849789108);
        latitude.add(22.2855225817732);


        longitude.add(-99.12766456604);
        longitude.add(116.397228240967);
        longitude.add(120.9822);
        longitude.add(90.40743827819824);
        longitude.add(106.84513092041016);
        longitude.add(35.6895);
        longitude.add(121.531846);
        longitude.add(-74.08175468444824);
        longitude.add(114.157691001892);

        location.add(R.drawable.mexico_city);
        location.add(R.drawable.beijing);
        location.add(R.drawable.manila);
        location.add(R.drawable.dhaka);
        location.add(R.drawable.jakarta);
        location.add(R.drawable.tokyo);
        location.add(R.drawable.taipei);
        location.add(R.drawable.bogota);
        location.add(R.drawable.hong_kong);

        for(int j=0;j<location.size();j++) {
            String query = "INSERT INTO LOCATIONDETAILS(SNO,NAME,LATITUDE,LONGITUDE,LOCATION) VALUES( '" + sno.get(j) + "','"+ name.get(j)+"','" + latitude.get(j) + "','" +longitude.get(j)+ "','"+ location.get(j)+"')";
            sq.execSQL(query);
            System.out.println("data inserted");

        }
         initializeMap();
        SQLiteDatabase sqr=dbhelper.getReadableDatabase();
        String fetchdetails="SELECT * FROM LOCATIONDETAILS";
        Cursor cs= sqr.rawQuery(fetchdetails, null);


        DatabaseUtils udb=new DatabaseUtils();
        udb.dumpCursor(cs);

        System.out.println("fetched");
        cs.close();
    }

    public void initializeMap() {

        googlemap = ((MapFragment) getFragmentManager().findFragmentById(R.id.maps)).getMap();


        if ((googlemap==null)){
            System.out.println("googlemap null");
        }


        googlemap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                System.out.println(latLng.latitude + "LATITUTE " + latLng.longitude + "Longitude");

               for (int i=0;i<location.size();i++){
                   icon=BitmapDescriptorFactory.fromResource(location.get(i));
                   if(latLng.latitude==latitude.get(i) &&latLng.longitude==longitude.get(i)){
                       googlemap.addMarker(new MarkerOptions().position(latLng).title(name.get(i)).icon(icon));
                   }
               }
            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
