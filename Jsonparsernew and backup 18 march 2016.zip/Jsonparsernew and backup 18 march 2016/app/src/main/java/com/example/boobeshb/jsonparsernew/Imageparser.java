package com.example.boobeshb.jsonparsernew;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;

/**
 * Created by boobeshb on 08-03-2016.
 */
public class Imageparser {
    InputStream inputStream=null;
    JSONObject jsonObject;
    String json;
    static   Bitmap s;
    public Bitmap getJSONfromURL(String URL){


        try {
            s = BitmapFactory.decodeStream((InputStream)new URL(URL).getContent());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return  s;

       /* try{
            //
           *//* URL url=new URL(URL);
            HttpPost hpost = new HttpPost(url.toURI());
            HttpClient httpclient = new DefaultHttpClient();
            HttpResponse response = httpclient.execute(hpost);
            HttpEntity entity=response.getEntity();
            inputStream =entity.getContent();
*//**//*
            BufferedInputStream sd=new BufferedInputStream(inputStream);
*//**//*
            s=BitmapFactory.decodeStream(inputStream);

            System.out.println("BITMAP PARSER");*//*


        }catch (UnsupportedEncodingException e){
            e.printStackTrace();
        }catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (URISyntaxException u){
            u.printStackTrace();
        }*/
        /*return  s;
*/
    }





}
