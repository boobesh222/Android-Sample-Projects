package com.example.boobeshb.jsonparsernew;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 03-03-2016.
 */
public class Customadapter extends BaseAdapter {
    List<String>  categories =new ArrayList<String>();;
    int listLength;
    Context c;
    String categoriesarray[]=new String[]{};
    String array[];
    List<Bitmap> bitmapimages=new ArrayList<Bitmap>();




    public Customadapter(Context appContext,List<String> a,int length,List<Bitmap> bitmapimages){

        categories=a;
        listLength=length;
        c=appContext;
        this.bitmapimages.clear();
        System.out.println("bitmapimages SIZE" + this.bitmapimages.size());
        this.bitmapimages=bitmapimages;
        System.out.println("bitmapimages SIZE AFTER ADDING" +this.bitmapimages.size());

        array=categories.toArray(categoriesarray);
        System.out.println(categoriesarray+ "categories array"+"   "  +  "  BITMAPIMAGES SIZE" +bitmapimages.size() );
        System.out.println(array+ " array");

    }




    @Override
    public int getCount() {
        return listLength;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inf=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view= inf.inflate(R.layout.viewlayout,null);
        System.out.println( position + "CUSTOM ADAPTER ");
        TextView tv=(TextView)view.findViewById(R.id.textview);
        ImageView df=(ImageView)view.findViewById(R.id.imageview);
        System.out.println(position+"POSITION");
        tv.setText(array[position]);
        df.setImageBitmap(bitmapimages.get(position));

        return view;
    }
}
