package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 23-03-2016.
 */
public class Homefragment extends Fragment {

    String name;

    List<String> image= new ArrayList<String>();
    List<String> categoryname=new ArrayList<String>();
    JSONObject values;
    Bundle b=getArguments();
    Recycleviewadapter recycleviewadapter;


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        System.out.println("ONATTACH HOME Fragment");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        JSONArray user;
        new Fetchimage(getActivity(),"men").fetchimage();
        View v=inflater.inflate(R.layout.recyclerviewlayout,null);
        RecyclerView recyclerView=(RecyclerView)v.findViewById(R.id.Recyclelayout);
        recycleviewadapter= new Recycleviewadapter(getActivity(),getFragmentManager());
        RecyclerView.LayoutManager rvlaymanager=new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(rvlaymanager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(recycleviewadapter);





        //recyclerView.addOnItemTouchListener(new RecyclerItemClickListener);

        /*ListView listview=(ListView)v.findViewById(R.id.listview_fragmentlayout);
        System.out.println("BEFORE SETTING ADAPTER");

        listview.setAdapter(new Genericlistview(getActivity()));


        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedmenu=Retailappmodel.categorynames.get(position);
                new Contentdetails(selectedmenu,getActivity(),position);
                Fragment fragment= new Innerlistviewfragment();
               int a = getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment).addToBackStack(null).commit();
                System.out.println("back stack return value " + a);

                Toast.makeText(getActivity(), "selectedmenu" + selectedmenu, Toast.LENGTH_SHORT).show();
            }
        });*/

        return v;
    }
}
