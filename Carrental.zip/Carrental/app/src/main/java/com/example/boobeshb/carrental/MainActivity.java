package com.example.boobeshb.carrental;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class MainActivity extends Activity {
    ListView lv;
    int images[]={R.drawable.persons,R.drawable.chiller,R.drawable.cfive,R.drawable.gpattern,R.drawable.heater,R.drawable.acauto};
    int pickup[]={R.drawable.airport,R.drawable.meet};
    int carslogo[]={R.drawable.carsone,R.drawable.cars,R.drawable.carsthree,R.drawable.carsfour};
    int cmpylogo[]={R.drawable.c,R.drawable.ctwo,R.drawable.ctwo,R.drawable.cthree};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv=(ListView)findViewById(R.id.main_listview);
        lv.setAdapter(new Customadapter(getApplicationContext(),images,pickup,carslogo,cmpylogo));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
