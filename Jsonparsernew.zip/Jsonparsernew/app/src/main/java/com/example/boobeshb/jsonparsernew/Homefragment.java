package com.example.boobeshb.jsonparsernew;

import android.app.Activity;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boobeshb on 23-03-2016.
 */
public class Homefragment extends Fragment {

    String name;

    List<String> image= new ArrayList<String>();
    List<String> categoryname=new ArrayList<String>();
    JSONObject values;
    Bundle b=getArguments();


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        new Fetchimage(getActivity(),"men").fetchimage();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        JSONArray user;

       View v=inflater.inflate(R.layout.fragmentlayout,null);


       /* if (jsonObject.length()==0){
            System.out.println("JSON OBJECT SIZE IS GREATED THAN ZERO");
        }else {
            System.out.println("SIZE 0");
        }*/

        /*List<JSONObject> jsonObjectslist;

        try {
            System.out.println(Retailappmodel.jsonObject.length()+"LENGTH OF JSON OBJECT ");
            user =Retailappmodel.jsonObject.getJSONArray("men");
            int nodelength = user.length();
            System.out.println(nodelength + "nodelength");
            Retailappmodel.image.clear();
            Retailappmodel.categorynames.clear();
            jsonObjectslist = new ArrayList<JSONObject>();
            for (int i = 0; i < nodelength; i++) {

                values = user.getJSONObject(i);
                JSONArray listNames = values.names();
                   *//* JSONArray valuesone=values.getJSONArray("1");
                    System.out.println(listNames.length()+"LIST NAMES LENGTH" +listNames.toString());
                    System.out.println(i + "i value");*//*
                String category1 = values.getString("category");
                Retailappmodel.categorynames.add(category1);
                String images = values.getString("images");
                Retailappmodel.image.add(images);
                Toast.makeText(getActivity(), "image size "+image.size() , Toast.LENGTH_SHORT).show();
                jsonObjectslist.add(values);

            }

           new Imageparse(getActivity()).execute();
           for(String s:image){
                System.out.println(s+"IMAGES WEBSITES");
           }



        } catch (JSONException e) {
            e.printStackTrace();
        }*/


        ListView listview=(ListView)v.findViewById(R.id.listview_fragmentlayout);
        System.out.println("BEFORE SETTING ADAPTER");

        listview.setAdapter(new Genericlistview(getActivity()));

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedmenu=Retailappmodel.categorynames.get(position);
                new Contentdetails(selectedmenu,getActivity(),position);
                Fragment fragment= new Innerlistviewfragment();
                getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment).addToBackStack("").commit();
                Toast.makeText(getActivity(), "selectedmenu" + selectedmenu, Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }
}
