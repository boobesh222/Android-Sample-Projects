package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by boobeshb on 30-03-2016.
 */
public class Landingpagefragments extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Bundle bundle =getArguments();
        int position=bundle.getInt("position");
        View v=inflater.inflate(R.layout.landingpage, null);
        ImageView imageView=(ImageView)v.findViewById(R.id.landingpage_imageviewone);
        TextView textView=(TextView)v.findViewById(R.id.landingpage_textview);
        TextView textView1=(TextView)v.findViewById(R.id.landingpage_size);
        imageView.setImageBitmap(Retailappmodel.productimages.get(position));
        textView.setText("INR " + Retailappmodel.price.get(position));
        textView1.setText(""+Retailappmodel.productsize.get(position));
        return v;
    }
}
