package com.example.boobeshb.jsonparsernew;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by boobeshb on 29-03-2016.
 */
public class Innerlistviewfragment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.menus,null);
        ListView varientsname=(ListView)view.findViewById(R.id.menus_listviewone);
        varientsname.setAdapter(new Varientsnameadapter(getActivity()));

        varientsname.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle=new Bundle();
                bundle.putString("hai", " hai");
                bundle.putInt("position", position);
                System.out.println("position" + bundle.getInt("position"));
                Fragment fragment=new FinalproductsviewFragments();
                fragment.setArguments(bundle);

                getFragmentManager().beginTransaction().replace(R.id.framelayout_main,fragment).commit();

            }
        });
        return view;
    }
}
